﻿using System.ComponentModel.DataAnnotations;

namespace POEv4.Models
{
    public class Venue
    {
        [Key]
        public int VenueID { get; set; }//PK
        [Display( Name = "Venue Name:")]
        public string VenueName { get; set; }
        [Display(Name = "Venue Location:")]
        public string VenueLocation { get; set; }
        [Display(Name = "Venue Capacity:")]
        public string VenueCapacity { get; set; }
        [Display(Name = "Image Url")]
        public string VenueImageUrl { get; set; }
        public List<Booking> Bookings { get; set; } = new();
    }
}
