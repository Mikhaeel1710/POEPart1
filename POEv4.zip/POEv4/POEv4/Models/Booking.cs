﻿using Microsoft.Extensions.Logging;
using System.ComponentModel.DataAnnotations;

namespace POEv4.Models
{
    public class Booking
    {

        [Key]
        public int BookingID { get; set; }
        public int EventID { get; set; }
        public Event? Event { get; set; }
        public int VenueID { get; set; }
        public Venue? Venue { get; set; }
        public string CustomerName { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerPhone { get; set; }
       
    }
}
