﻿using System.ComponentModel.DataAnnotations;

namespace POEv4.Models
{
    public class Event
    {
        [Key]
        public int EventID { get; set; }
      
        public string EventName { get; set; }
        public string EventDescription { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
