﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using POEv4.Models;

namespace POEv4.Data
{
    public class POEv4Context : DbContext
    {
        public POEv4Context (DbContextOptions<POEv4Context> options)
            : base(options)
        {
        }

        public DbSet<POEv4.Models.Venue> Venue { get; set; } = default!;
        public DbSet<POEv4.Models.Event> Event { get; set; } = default!;
        public DbSet<POEv4.Models.Booking> Booking { get; set; } = default!;
    }
}
